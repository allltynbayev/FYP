package com.text.textr01.locationtracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    EditText Username,Password;
    Button LoginButton;
    String UsernameText,PasswordText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Username=(EditText)findViewById(R.id.username);
        Password=(EditText)findViewById(R.id.password);
        LoginButton=(Button)findViewById(R.id.loginbutton);

        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                UsernameText=Username.getText().toString();
                PasswordText=Password.getText().toString();



                if(UsernameText.equals("admin"))
                {

                    if(PasswordText.equals("admin"))
                    {
                        Intent i=new Intent(MainActivity.this,UserActivity.class);
                        startActivity(i);


                        Toast.makeText(MainActivity.this, "Welcome admin..", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(MainActivity.this, "Please enter correct password..", Toast.LENGTH_SHORT).show();
                    }

                }

            }
        });
    }


    @Override
    public void onBackPressed() {

    }
}
