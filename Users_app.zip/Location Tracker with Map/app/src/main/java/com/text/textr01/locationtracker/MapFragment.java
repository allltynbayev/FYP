package com.text.textr01.locationtracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MapFragment} factory method to
 * create an instance of this fragment.
 */
public class MapFragment extends Fragment {

    private static final int LOCATION_REQUEST_CODE = 1;
    ArrayList<String> DriverLocationList = new ArrayList<>();
    ArrayList<String> DriverNameList = new ArrayList<>();
    Button GetDriversLocation;
    private FusedLocationProviderClient fusedLocationClient;
    private boolean isPermissionRequested = false;

    GoogleMap map;
    String date;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Initialize view
        View view = inflater.inflate(R.layout.fragment_map, container, false);

        // Initialize map fragment
        final SupportMapFragment supportMapFragment = (SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.google_map);

        GetDriversLocation = view.findViewById(R.id.getDriversLocation);
        final EditText busIdEditText = view.findViewById(R.id.busIdEditText);
        Button searchButton = view.findViewById(R.id.searchButton);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String busId = busIdEditText.getText().toString();
                if (!busId.isEmpty()) {
                    showBusLocations(busId);
                } else {
                    Toast.makeText(getContext(), "Please enter a Bus ID", Toast.LENGTH_SHORT).show();
                }
            }
        });
        GetDriversLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final DatabaseReference RootRef;
                RootRef = FirebaseDatabase.getInstance().getReference();

                date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
                DriverLocationList.clear();


                RootRef.child("Users").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            DriverLocationList.add(snapshot.child(date).child("locationname").getValue().toString());
                            DriverNameList.add(snapshot.child("name").getValue().toString());

                        }

                        for (int i = 0; i < DriverLocationList.size(); i++) {
                            double latD = Double.parseDouble(DriverLocationList.get(i).split(" ")[0]);
                            double longtD = Double.parseDouble(DriverLocationList.get(i).split(" ")[1]);

                            MarkerOptions marker = new MarkerOptions().position(new LatLng(latD, longtD)).title("Bus Driver " + DriverNameList.get(i));
                            map.addMarker(marker);
                        }

                        LatLng Bishkek = new LatLng(Double.parseDouble(DriverLocationList.get(0).split(" ")[0]),
                                Double.parseDouble(DriverLocationList.get(0).split(" ")[1]));

                        map.animateCamera(CameraUpdateFactory.newLatLngZoom(Bishkek, 15), 3000, null);

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });


        // Async map
        supportMapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(final GoogleMap googleMap) {
                map = googleMap;

                // Coordinates for Bishkek
                LatLng Bishkek = new LatLng(42.8746, 74.5698);

                map.moveCamera(CameraUpdateFactory.newLatLngZoom(Bishkek, 13));
                if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    ActivityCompat.requestPermissions(getActivity(), new String[] {
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    }, LOCATION_REQUEST_CODE);

                    isPermissionRequested = true;
                    return;
                }
                map.setMyLocationEnabled(true);
                fusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());

                fusedLocationClient.getLastLocation()
                        .addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                            @Override
                            public void onSuccess(Location location) {
                                // Got last known location. In some rare situations, this can be null.
                                if (location != null) {
                                    LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 15));
                                }
                            }
                        });
                // Set camera position to Bishkek
            }
        });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        if (isPermissionRequested) {
            if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                map.setMyLocationEnabled(true);
                fusedLocationClient = LocationServices.getFusedLocationProviderClient(getActivity());

                fusedLocationClient.getLastLocation()
                        .addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                            @Override
                            public void onSuccess(Location location) {
                                // Got last known location. In some rare situations, this can be null.
                                if (location != null) {
                                    LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
                                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 15));
                                }
                            }
                        });
            }

            isPermissionRequested = false;
        }
    }

    private void showBusLocations(final String busId) {

        final DatabaseReference driversRef = FirebaseDatabase.getInstance().getReference().child("Drivers").child(busId);
        driversRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {

                    map.clear(); // Clear previous markers
                    List<LatLng> points = new ArrayList<>();
                    points.add(new LatLng(42.88788906982961, 74.6386003251535)); // San Francisco
                    points.add(new LatLng(42.88531174446525, 74.61199149587502)); // Los Angeles
                    points.add(new LatLng(42.86934623085859, 74.61131082126586));
                    points.add(new LatLng(42.8702470495686, 74.58764756945584));
                    points.add(new LatLng(42.84360357872023, 74.58596317991417));
                    points.add(new LatLng(42.843819822291316, 74.56835237931898));
                    points.add(new LatLng(42.82960731266825, 74.56928687683853));
                    points.add(new LatLng(42.829557366246355, 74.56306089402555));
                    points.add(new LatLng(42.80512449746108, 74.56931477626499));


                    // Add the polyline to the map
                    PolylineOptions polylineOptions = new PolylineOptions().addAll(points).width(10).color(Color.BLUE);
                    map.addPolyline(polylineOptions);

                    LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder();

                    int counter = 0;
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        String locationName = snapshot.child("locationname").getValue(String.class);
                        String driverName = snapshot.child("name").getValue(String.class);

                        if (locationName != null) {
                            double latD = Double.parseDouble(locationName.split(" ")[0]);
                            double longtD = Double.parseDouble(locationName.split(" ")[1]);

                            MarkerOptions marker = new MarkerOptions().position(new LatLng(latD, longtD)).title("Bus Driver " + driverName);
                            map.addMarker(marker);

                            counter++;


                            boundsBuilder.include(new LatLng(latD, longtD));
                        }
                    }
                    // bounds is not empty
                    LatLngBounds bounds = boundsBuilder.build();

                    int padding = 100; // Adjust as needed
                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                    map.animateCamera(cameraUpdate);

                } else {

                    Toast.makeText(getContext(), "Could not find BUS ID", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle error
            }
        });
    }


}